﻿
public class ODIRatingPlayer : IRating
{
    private Logger _logger;
    public ODIRatingPlayer(Logger logger)
    {
        _logger = logger;
    }
    public void Rate(CricketRating item)
    {
        _logger.Log("ODI Format");
        if (item.StrikeRate > 95)
        {

            _logger.Log($"star player:: {item.Name}");
            _logger.Log("Applicable for special bonus");
        }
        else
        {
            _logger.Log($"Average player:: {item.Name}");
            _logger.Log("Not applicable for bonus");
        }
    }
}

public class UnknownRatingPlayer : IRating
{
    private Logger _logger;
    public UnknownRatingPlayer(Logger logger)
    {
        _logger = logger;
    }
    public void Rate(CricketRating item)
    {
        _logger.Log("UnknownRatingPlayer");
    }
}