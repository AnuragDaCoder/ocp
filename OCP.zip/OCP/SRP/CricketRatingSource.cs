﻿namespace SRP
{
    public class CricketRatingSource
    {
        const string jsonpath = "C:\\Users\\611184113\\source\\repos\\SRP\\SRP\\cricket.json";
        string xmlpath = Path.Combine(Environment.CurrentDirectory, "cricket.xml");
        public string CricketRatingFromJson()
        {
            return File.ReadAllText(jsonpath);
        }
        public string CricketRatingFromXML()
        {
            return xmlpath;
        }
    }
}
