﻿var player = new CricketSpecialistInAFormat();
player.OverAllRate(Source.XML);
