﻿
public class CricketRating
{
    public string Name { get; set; }
    public string Format { get; set; }
    public decimal Average { get; set; }
    public decimal StrikeRate { get; set; }
}

public enum CricketFormat
{
    T20,
    ODI
}

public enum Source
{
    JSON,
    XML
}