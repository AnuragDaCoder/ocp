﻿
using Newtonsoft.Json;

public class Logger
{
    public void Log(string message)
    {
        Console.WriteLine(message);
    }
}
