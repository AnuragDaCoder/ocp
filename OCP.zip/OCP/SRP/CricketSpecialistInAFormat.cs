﻿using SRP;
internal class CricketSpecialistInAFormat
{
    public Logger Logger { get; set; } = new Logger();
    public CricketRatingSource sourceObj = new ();
    public CricketDeserializer cricketDeserializerObj = new();
    public int OverAllRating { get; set; }
    public void OverAllRate(Source source)
    {
        List<CricketRating> ratingObject = new();
        var ratingStr = new RatingSource(source, sourceObj, cricketDeserializerObj);
        ratingObject= ratingStr.cricketRating();

        foreach (var item in ratingObject)
        {
            Logger.Log("-----------------------------");
            var factory = new SRP.Factory.CricketRatingFactory(Logger);
            var rating =factory.Create(item);
            rating.Rate(item);
        }
    }
}