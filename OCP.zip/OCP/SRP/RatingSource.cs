﻿public class RatingSource
{
    private readonly Source _source;
    private readonly SRP.CricketRatingSource _sourceObj;
    private readonly CricketDeserializer _cricketDeserializerObj;
    public RatingSource(Source source, SRP.CricketRatingSource sourceObj, CricketDeserializer cricketDeserializerObj)
    {
        _source = source;
        _sourceObj = sourceObj;
        _cricketDeserializerObj = cricketDeserializerObj;
    }

    public List<CricketRating> cricketRating()
    {
        if (Source.JSON == _source)
        {
            var ratingJsonStr = _sourceObj.CricketRatingFromJson();
            return _cricketDeserializerObj.cricketRatingDeserializeJson(ratingJsonStr);
        }
        else if (Source.XML == _source)
        {
            var ratingXMLStr = _sourceObj.CricketRatingFromXML();
            return _cricketDeserializerObj.cricketRatingDeserializeXml(ratingXMLStr);
        }
        return new List<CricketRating>();
    }
}