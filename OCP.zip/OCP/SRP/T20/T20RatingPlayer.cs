﻿public interface IRating 
{ 
    public void Rate(CricketRating item);
}

public class T20RatingPlayer : IRating
{
    private Logger _logger; 
    public T20RatingPlayer(Logger logger)
    {
        _logger=logger;
    }
    public void Rate(CricketRating item)
    {
        _logger.Log("T20 Format");

        if (item.StrikeRate > 150 && item.Average > 40)
        {
            _logger.Log($"star player:: {item.Name}");
            _logger.Log("Applicable for special bonus");
        }
        else
        {
            _logger.Log($"Average player:: {item.Name}");
            _logger.Log("player will be given next 10 chances to prove");
            _logger.Log("Not applicable for bonus");
        }
    }
}