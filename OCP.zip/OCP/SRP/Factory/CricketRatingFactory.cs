﻿namespace SRP.Factory
{
    public class CricketRatingFactory
    {
        private readonly Logger _logger;
        public CricketRatingFactory(Logger logger)
        {
            _logger = logger;
        }

        public IRating Create(CricketRating item)
        {
            Enum.TryParse(item.Format, out CricketFormat format);
            switch (format)
            {
                case CricketFormat.T20:
                    return new T20RatingPlayer(_logger);
                case CricketFormat.ODI:
                    return new ODIRatingPlayer(_logger);
                default:
                    return new UnknownRatingPlayer(_logger);
            }
        }
    }
}
